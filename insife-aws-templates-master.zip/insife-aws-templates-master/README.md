# insife-aws-templates
## [This is the documentation for the Stacks](./documentation/stack-deployment.md)