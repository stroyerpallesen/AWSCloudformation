# How to create new certificate for the Remote Desktop Gateway

## Prerequisites
- OpenSSL: https://www.openssl.org/source/
- Download link for compiled Windows files: https://sourceforge.net/projects/openssl/
- Make sure you have access to the DNS zone for the certificate Subject Name - for example the insife.cloud DNS zone.
- Remember to create a DNS A record in the zone that points to the Remote Desktop Gateway's public IP address.

## Existing private key
- Existing private key (private.key) is stored in KeyCore LastPass account in
Shared-Insife\Certificates\remote.insife.cloud (Private Key)

## Windows configuration of OpenSSL
- Extract zip-file to directory - for example: C:\OpenSSL
- Add C:\OpenSSL\bin to your local Path environment variable
- Add a new System Variable:
  OPENSSL_CONF = C:\OpenSSL\bin\openssl.cnf
- Copy the files from Insife Git repository: insife-aws-templates\certificates\rdgw to C:\OpenSSL\certificates\insife\rdgw

## Before running the command below
- Open Administrative cmd
- cd C:\OpenSSL\certificates\insife\rdgw

## How to create a new private key
- openssl genrsa -out private-key.key 2048

## How to create a new certificate request file:
- openssl req -new -key private.key -out csr.txt

## How to create a new pfx-file to import on Remote Desktop Gateway
-  When you receive the certificate from the Certificate Authority provider make a file for the RD Gateway buttom certicate and a chain file for the upper trust chain.
For example, look at the files in this folder, you just create .cer files from the content you received from the CA.
- run export-certificate-to-pfx.cmd

## Copy the pfx-file to the Remote Desktop Gateway and change the certificate
- Use RDP to copy the file to the RDGW
- Import the pfx file to the Local Computer/Personal Store
- Import the certificate using the Remote Desktop Gateway Manager
- Right-click the server in the console and select Properties
- Click Select and existing certificate ... and import from the Certificate store.

## Notes
Once you have created and imported the pfx file, you could in principle delete the private.key - but, if the RDGW needs to be rebuild, you will need it or you'll have to create a new private key and certificate request.

Since the pfx-file stores the private key, it is good practice to password protect it. The pfx file in this reposistory is password protected, and the password is lost in the void.


