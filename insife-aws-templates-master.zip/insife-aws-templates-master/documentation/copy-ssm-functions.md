# HowTo use the Copy SSM parameters function(s)
The copy ssm functions are located in all the client accounts, and created using the [copy-ssm.yml](../CFTemplates/copy-ssm.yml "CloudFormation template") CloudFormation Template

## Overview
This is how the function is implemented and the components involved

![Overview](img/CopySSMParameters.png "Overview")

## Steps involved
1. Find the Account ID's needed or use All
1. Create an SNS message to the Copy SSM function(s)

### Step 1

Force all accounts to update the SSM parameters, use All, and skip to the next Step

To collect individual accounts, sign in to the console, using a user id with access to submit SNS messages

Use the link https://console.aws.amazon.com/console/home

<p align="center">
  <img style="margin: auto;display:block;" src=img/AWSSign-In.png width=350 title="AWS Login as IAM user">
</p>

Go to the organization overview in the root account (in the account menu)

<p align="center">
  <img style="margin: auto;display:block;" src=img/MyOrganization.png width=400 title="MyOrganization">
</p>

In the accounts overview, collect the Account Id's needed

![Account Id's](img/AccountIds.png "Account Id's")

### Step 2

Now, the information needed to send an SNS notification to the Lambda function(s), is available
Either search for SNS or select it directly, in the Services dropdown

![Find SNS](img/FindSNS.png "Find SNS")

First we need to locate the Topic ARN to send the SNS message to  
Chose the Topics menu item, to get a the topic ARN (in this case arn:aws:sns:eu-west-1:775861559851:SSMCopyTopic)

<p align="center">
  <img style="margin: auto;display:block;" src=img/CopySSMSNSTopic.png width=700 title="Find SNS Topic">
</p>

Return to the SNS Dashboard and choose to publish an SNS message

<p align="center">
  <img style="margin: auto;display:block;" src=img/PublishSNSLink.png width=500 title="Publish SNS Menu">
</p>

Fill in the fields as shown below. The Topic from the topics tab, anything in the Subject and All or a list of Account Id(s), in the Message  
Then press Publish Message

![Publish SNS Message](img/PublishCopySSMSNS.png "Publish SNS Message")

To verify the change, switch to one of the target accounts and open the SSM parameter store. If the timestamp of the parameters is current, then the copy was successful

![SSM Parameter Store](img/SSMParameterStore.png "SSM Parameter Store")