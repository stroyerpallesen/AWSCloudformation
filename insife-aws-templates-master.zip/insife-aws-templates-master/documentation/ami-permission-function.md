# HowTo use the AMI permission function
The AMI permission function is created in the root account, using the [ami-access-function.yml](../CFTemplates/ami-access-function.yml "CloudFormation template") CloudFormation Template

## Overview
This is how the function is implemented and the components involved

![Overview](img/AMIPermissionfunction.png "Overview")

## Steps involved
1. Find the AMI Id
1. Find the OU of the Parent organizational unit, for which the AMI access should be changed
1. Create an SNS message to the AMI permission function

### Step 1

Sign in to the console, using a user id with access to submit SNS messages

Use the link https://console.aws.amazon.com/console/home

<p align="center">
  <img style="margin: auto;display:block;" src=img/AWSSign-In.png width=350 title="AWS Login as IAM user">
</p>

Go to the EC2 Service and choose the AMI menu item on the left

![EC2 Dashboard](img/AWSEC2Dashboard.png)

Locate the AMI which should have access permissions added or removed

![AMI Id](img/AMIId.png)

### Step 2

Go to the organization overview (in the account menu)

<p align="center">
  <img style="margin: auto;display:block;" src=img/MyOrganization.png width=400 title="MyOrganization">
</p>

Go to the organize accounts

<p align="center">
  <img style="margin: auto;display:block;" src=img/OrganizeAccounts.png width=400 title="Organize Accounts">
</p>

Now choose the parent of the accounts, for which access should be changed  
This picture shows the selection of the root organizational account. On the right side in the blue box, pick the latter part of the URL - that is the OU of the Root and should be used to give all accounts in the root of the organization access to the AMI (the OU for the Root organization is r-5han)

![Organization Root](img/OrganizationRoot.png "Organization Root")

To give access to all e.g. development accounts, select the Development OU  
Here the ID is still the latter part of the ARN, but also shown separately as the ID (the OU for the Development  organization is ou-5han-toz1mchp)

![Organization Development](img/OrganizationDevelopment.png "Organization Development")

### Step 3

Now, the information needed to send an SNS notification to the Lambda function, is available
Either search for SNS or select it directly, in the Services dropdown

![Find SNS](img/FindSNS.png "Find SNS")

First we need to locate the Topic ARN to send the SNS message to  
Chose the Subscriptions menu item, to get a the topic ARN (in this case arn:aws:sns:eu-west-1:775861559851:AMIPermissionTopic)

![Find SNS Topic](img/SNSSubscriptions.png "Find SNS Topic")

Return to the SNS Dashboard and choose to publish an SNS message

<p align="center">
  <img style="margin: auto;display:block;" src=img/PublishSNSLink.png width=500 title="Publish SNS Menu">
</p>

Fill in the fields as shown below. The Topic from the subscription tab, anything in the Subject, Add or Remove in the Message, and then two String attributes Ou - the Parent of the accounts for which the action is to be performed and AmiId - the ID of the AMI to receive the change  
Then press Publish Message

![Publish SNS Message](img/PublishSNS.png "Publish SNS Message")

To verify the change, look at the Permissions tab of the AMI, and see the accounts give access, or no longer in the list

![AMI Permission](img/AMIPermission.png "AMI Permission")