# Stack deployment for Insife stacks

## The account structure
The intention is to have a root account for AD, RDGW and other generic infrastructure, and client specific accounts for dev, possibly pp and for prod

## Initial setup on the root account
### Install the root-vpc stack
The root-vpc stack creates the root VPC, public, dmz and private subnets in all AZs, route tables, an internet gateway, NAT gateway(s) and VPC FlowLogs

### Install the passwordmanager as a prereq for the rds client stacks 
These stacks are located in the password-manager repo, and the stack s3bucket installs an S3 bucket to contain the source code zip for the password-manager stack.  
The sourcecode zip file needs to be copied to the bucket, prior to launching the password-manager stack  
The password-manager stack needs the bucket and the zip file name, to install the password manager lambda

### Install the ssm topic as a prereq for the ssm copy stacks
The root-ssm-topic needs to be created just once in the root account. It creates an SNS topic and the policy allowing anyone in the root account to publich to it 

### Install the AD
Refer to the Managed AD installation guide

### Install the RDGW
Refer to the RDGW installation guide

## Per client account you will need to do the following
### Install the root peering role and ssm role stacks
Now that you have a client account (or two), you need to apply a stack in root, giving these accounts access to root  
The stack to apply in root is root-vpc-peering-roles. This stack makes it posible for the client vpc to create a peering connection from the client to root  
Next you create the root-ssm-roles stack  
It gives the client account(s) access to copy ssm parameters (needed for AD joins)

### Install policies and roles
In the client account you create the iam-policies stack and subsequently the iam-roles stack

### Install the cloud trail pieces
Create the cloudtrail stack. It creates an S3 bucket, the required policy, and turns on cloud trail for the account

### Install the vpc
First you choose the CIDR for the vpc. Dev accounts are in the 10.10.* address space, validation/pre-pred are in the 10.50.* address space and prod are in 10.100.*  
Then you run the vpc stack with the chosen CIDR

### For peering to work, there is an additional root stack needed
In the root account you will need to create the peering routes stack called peer-routing-from-root

### Back in the client account you copy the ssm parameters
Create the copy-ssm stack to copy ssm parameters from the root account and down to the client  
This stack can be deleted and recreated, if parameters are updated in root, as it overwrites existing (no parameters are deleted)

## Set up the application servers
### Start with the RDS instance
Create the rds stack

### Next create the windows servers
Create the application stack

# Per Client Account Stack Creation

|Template|Description|Creation Order|Account|
|--------|-----------|-----|-------|
|root-vpc-peering-roles.yml|Give Client Account permission to peer with Root VPC|1|Insife Root|
|root-ssm-roles.yml|Give Client Account permission to fetch SSM Parameters|2|Insife Root|
|iam-policies.yml|Basic permission blocks|3|Client|
|iam-roles.yml|Roles using permissions|4|Client|
|cloudtrail.yml|AWS Audittrail|5|Client|
|vpc.yml|Client VPC|6|Client|
|peer-routing-from-root.yml|Create network connection to root VPC|7|Insife Root|
|copy-ssm.yml|Copy SSM parameters from Root to Client|8|Client|
|Send SNS message !!!|To Copy SSM parameters a SNS message must be sent to topic in Root|9|Insife Root|
|ssl-cert.yml|Create SSL Certificate for environment|10|Client|
|EC2 API / Console|Share Insife custom AMI with *Client* account ID|11|Insife Root|
|application.yml|Create application layer - be careful with imports and remember to change SSM parameter inputs !|12|Client|


# Post-deploy Checklist
- In the Insife Root account, check that the routing-tables dont have any Blackholed routes to the new subnet created.