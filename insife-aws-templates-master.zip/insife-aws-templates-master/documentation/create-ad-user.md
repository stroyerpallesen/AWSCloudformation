# Create new AD user
## Follow this step by step guide, to add an AD user (standard, service or Admin)
### Log in to RDGW
Open RDP - enter the computer to access (RDGW is remote.insife.cloud) and user name if not already filled in (insife-ad.cloud\xx)

![Remote desktop GW Computer](img/RDPComputer.png)

### Open AD tool

When on the RDGW, find the AD Administration Center in Administrative Tools

![Remote desktop GW ADAC](img/RDGWADAC.png)

Navigate to the insife-ad domain

![Insife AD](img/ADInsife-AD.png)

### Create user

Right click, select New and User

![Insife AD New user](img/ADNewUser.png)

Enter relevant user information and the user ID - when done press Ok

![Insife AD Create user](img/ADCreateUser.png)

### Additional options

If the user needs to be able to access the RDGW, then make sure you make the user member of the Remote Desktop Gateway Users group

![Insife AD Add group](img/RDGWGroup.png)

If you would like to create an Admin user, then 1. please place the user in INSIFE_AD\Admins folder

![Insife AD Place in Admins](img/ADAdmins.png)

and 2. add an additional group (AWS Delegated Administrators)

![Insife AD Place in Admins](img/ADAdminGroup.png)