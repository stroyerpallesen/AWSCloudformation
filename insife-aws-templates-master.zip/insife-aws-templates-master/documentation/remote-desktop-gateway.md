# Remote Desktop Gateway Guide

## Deployment
##### Create KeyPair
First, manually create an EC2 KeyPair for the RD Gateway named remote-desktop-gateway
You cannot create KeyPairs using CloudFormation.
Make sure to save the KeyPair .pem file somewhere safe - like LastPass

### AWS RD Gateway QuickStart
Deploy a remote desktop gateway from the following aws quickstart template: 
https://github.com/aws-quickstart/quickstart-microsoft-rdgateway/blob/master/templates/rdgw-domain.template

#### Stack parameters
| Parameter | Value |
| --- | --- |
| StackName | rdgw-quickstart |
| DomainAdminPassword | use the password defined on the Active Directory stack |
| DomainAdminUser |	Admin |
| DomainDNSName |	insife-ad.cloud |
| DomainNetBIOSName	 | INSIFE-AD |
| KeyPairName	| remote-desktop-gateway |	
| NumberOfRDGWHosts	| 1	|
| PublicSubnet1ID	| subnet-095fbd654cef3fe85 |
| PublicSubnet2ID	| subnet-02f045e03af693bcf |
| QSS3BucketName |	aws-quickstart |
| QSS3KeyPrefix	| quickstart-mcrosoft-rdgateway |	
| RDGWCIDR |	95.166.171.131/32 | RDGWInstanceType | t2.large |
| VPCID | vpc-0737c218abae244a1 |
 
Make sure you WAIT for the stack to finish until you proceed!

### Replace Remote Desktop Gateway resources with new stack
Deploy the resources from the remote-desktop-gateway.yml in this repository

#### Stack parameters
| Parameter | Value |
| --- | --- |
| StackName | remote-desktop-gateway |
| EnvironmentName | root |
| VpcStackName | vpcroot |

#### Stack resources
Access Security Group for the RD Gateway
An RdpTargets security group
An EC2 Profile and Role
SSM parameters for the RD Gateway security group id and the owner id (account)

Next, the RD Gateway from the quickstart needs to be detached from the quickstart stack and
configured to use the above resources instead.

#### Detaching the RD Gateway from the quickstart stack and it's resources

##### Detach from Autoscaling group
Go to EC2/AutoScaling group
Go to instances in AutoScaling group and select the instance
Choose Action > Detach
Check 'Add a new instance to the Auto Scaling group to balance the load'
Edit AutoScaling group Details 
Set Desired/Min/Max to 0 

##### Disassociate EIP and create a new EIP
Go to EC2 Elastic IPs
Disassociate the detached EC2 instace from the Elastic IP (since it is created by the stack)
Create new EIP
Name it remote-desktop-gateway
Associate the detached EC2 instance with the new Elastic IP

##### Detach existing security group and attach new security group
Detach existing security group from the EC2 instance and attach the Access Security Group created by the remote-desktop-gateway resources stack instead.

##### Replace the IAM instance role
On the EC2 instance, go to Actions > Instance Settings > Attach/Replace IAM Role.
Change the role to the one created by the remote-desktop-gateway stack.

#### Optionally remove the quickstart stack
When the RD Gateway has been detached from the autostaling group, and it's EIP, security group and IAM role has been replaced by the new resources from the remote-desktop-gateway resources stack, you can optionally delete the quickstart stack.

##### Rename instance name tag
Go to EC2 instances and rename the detached instance to 'remote-desktop-gateway'

#### RD Gateway Configuration
Log on to remote desktop gateway using rdp client
UserName: Admin
Password: Admin password defined for Active Directory
Domain: Dns domain defined for Active Directory - for example insife-ad.cloud

##### Install RSAT tools
Start cmd as Administrator 

##### Install RSAT tools to be able to configure AD and DNS
Install-WindowsFeature RSAT-AD-Tools,RSAT-DNS-Server -IncludeAllSubFeature

##### Rename RD Gateway
Rename the computer account to something meaningful - such as RDGW
Later, move the computer account in AD to the Shared Infrastructure OU (see the Active Directory guide)

