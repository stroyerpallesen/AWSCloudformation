# AWS Managed Active Directory documentation

## How to deploy
Deploy the cfn-template ad.yml in insife root account

Stack Parameter values

| Parameter | Value |
| --- | --- |
| StackName | insife-ad |
| DomainAdminPassword | (stored in KeyCore Lastpass account) |
| DomainDNSName | insife-ad.cloud |
| DomainNetBIOSName | INSIFE-AD |
| EnvironmentName | root |
| VPCStackName | vpcroot |

Make a note of the SSM parameters the template creates

## Prerequisites
#### Create/use an administrative server
- To configure Active Directory you need a domain joined Windows instance.
For example use the RD Gateway server.
- Before you continue, follow the guide to install the RD Gateway server
- When finished, log on to the domain joined RD Gateway server using domain=insife-ad.cloud, user=Admin and password

## Active Directory Configuration

Open adac.msc

#### Create OU's
Create OU for administrators: insife-ad.cloud/INSIFE-AD/Admins
Create OU for groups: insife-ad.cloud/INSIFE-AD/Groups
Create OU for shared infrastructure: insife-ad.cloud/INSIFE-AD/Shared-Infrastructure (for RDGW etc.)

#### Create User Accounts

##### The shared Admin user
Set password on Admin user account to Never Expire - otherwise your Admin account will be unusable after 3 months. Don't use the Admin user - Use Personal Admin user, so access can be traced. The password for the Admin user should be kept in a secure place. Ideally, it should be changed whenever it is used by anyone.

##### Personal Admin users
Create admin users in OU insife-ad.cloud/INSIFE-AD/Admins 
- Allan A.B. Thomsen (at@insife-ad.cloud)
- Christian Petersen (cp@insife-ad.cloud) 
- Per Stroyer Pallesen (psp@insife-ad.cloud)

Put the admin users in the group: insife-ad.cloud/AWS Delegated Groups/AWS Delegated Administrators. This group gives administrative access on the Active Directory and domain joined computers.

##### Domain join user
Create the following user account: insife-ad.cloud/INSIFE-AD/Users/SvcJoinDomain

Save password for svcJoinDomain user in KeyCore LastPass: Shared-Insife/Active Directory/SvcJoinDomain. NOTE: Perhaps, Insife need their own LastPass account for this.

#### Create Groups

##### Remote Desktop Users
This group is for allowing non-admins rdp access to Window clients. This group should be added to the Remote Desktop Gateway server if you want to allow non-admin users access through the RD Gateway. 

Create group for INSIFE Remote Desktop Users: insife-ad.cloud/INSIFE-AD/Groups/Remote Desktop Users

On the RD Gateway server open the RD Gateway Manager console > Policies > Connection Authorization Policies > Right Click Default-CAP > Requirements > Add Group. Also, add the group to the Resource Authorization Policies > Default-RAP

##### Domain Joiners  
Create group for domain joiners: insife-ad.cloud/INSIFE-AD/Groups/Domain Joiners
Add SvcDomainJoin to the Domain Joiners group

##### OU Creators
Create group for ou creators: insife-ad.cloud/INSIFE-AD/Groups/OU Creators
Add SvcDomainJoin to the OU Creators group

#### OU Delegated Rights

##### Domain Joiners rights on the Computers OU
Delegate control to the Domain Joiners group using the following guide:
https://docs.aws.amazon.com/directoryservice/latest/admin-guide/directory_join_privileges.html
Delegate the right on the Computers OU.

Security hardening: Don't assign the right to delete computer objects to the Domain Joiners - in case it is compromised, it will not be possible to delete all computer accounts of other customers. Ideally, create separate domain join user accounts for each Customer for better security. Use another account for deleting computer and user accounts.

##### OU Creators rights on the Computers OU
Delegate the right to create OU's to the group 'OU Creators' on the Computers OU.

Other than right to Write OU's, you need Modify Permission on Sub objects in order to set the ProtectedFromAccidentalDeletion:$true 

##### How to create a new OU from PowerShell
Install-WindowsFeature RSAT-AD-PowerShell (required module) and run the following powershell code:
        
    New-ADOrganizationalUnit -Name "Customer2" -Path "OU=Computers,OU=INSIFE-AD,DC=insife-ad,DC=cloud" -ProtectedFromAccidentalDeletion:$true

Please note the -ProtectedFromAccidentalDeletion parameter. When set it creates an explicit deny on Everone to delete the OU and sub-objects. Delete the explicit deny ACL in order to delete the OU. This protects your Active Directory objects from being mass-deleted by human error or bad intentions.

#### Group Policies

##### Disable the built-in firewall on the Windows Instances. 
Use the AWS security groups instead.

Open gpmc.msc and create a group policy to disable internal 
Windows Firewall. Name the policy 'INSIFE Disable Window Firewall'

Open Computer configuration and go to Administrative Templates > Network  > Network Connections > Windows Firewall.

Set the following two settings:

    Domain Profile = Disabled
    
    Standard Profile = Disabled

Attach policy to: insife-ad.cloud/INSIFE-AD/Computers OU

#### DNS
Open dnsmgmt.msc

##### Create a conditional forwarder for Amazon Provided DNS
Add conditional forwarder to Amazon Provided DNS - this will enable you to connect to and resolve ec2 instance names.

Conditional Forwarders > New Conditional Forwarder
Name: eu-west-1.compute.internal
IP: 10.0.0.2

Also, in case any private hosted zones are created create a similar conditional forwarder for these as well
For example:
Name: insife-private.local
IP: 10.0.0.2

Amazon provided DNS IP is always two addresses from the bottom of the VPC scope. So, when VPC scope is 10.0.0.0/16. Amazon provided DNS is 10.0.0.2.




