Install-WindowsFeature RDS-Gateway -IncludeManagementTools
Import-module RemoteDesktopServices
New-Item -Path RDS:\GatewayServer\CAP -Name Default-CAP -UserGroups 'Domain Admins@insife-ad.cloud','Remote Desktop Gateway Users@insife-ad.cloud' -AuthMethod 1
New-Item -Path RDS:\GatewayServer\RAP -Name Default-RAP -UserGroups 'Domain Admins@insife-ad.cloud','Remote Desktop Gateway Users@insife-ad.cloud' -ComputerGroupType 2
