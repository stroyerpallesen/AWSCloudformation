$AgentRootPath = "$Env:ProgramFiles\Amazon\AmazonCloudWatchAgent"
$AgentCtlPath = "$AgentRootPath\amazon-cloudwatch-agent-ctl.ps1"
$ConfigFilePath = "$AgentRootPath\config.json"

& $AgentCtlPath -m ec2 -a status
& $AgentCtlPath -m ec2 -a stop

# edit the config file 

# test the local config file
& $AgentCtlPath -a fetch-config -m ec2 -c file:$ConfigFilePath -s

# check logs in C:\programdata\amazon\AmazonCloudWatchAgent\Logs

# how to write config to ssm:
& aws ssm put-parameter --name "/insife/root/cw-agent/config-windows" --type "String" --value file://$ConfigFilePath --overwrite --region eu-west-1 

# how to fetch config from ssm
& $AgentCtlPath -a fetch-config -m ec2 -c ssm:/insife/root/cw-agent/config-windows -s

