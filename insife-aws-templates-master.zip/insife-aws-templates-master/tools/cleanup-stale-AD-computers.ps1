$date = (get-date).adddays(-120)
get-adcomputer -filter {passwordlastset -lt $date} -SearchBase "OU=Computers,OU=INSIFE-AD,DC=insife-ad,DC=cloud" -properties passwordlastset | remove-adobject -recursive -verbose -confirm:$false
